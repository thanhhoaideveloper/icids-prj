options.add_extension(os.getcwd() + '/crx/BIHMPLHOBCHOAGEEOKMGBDIHKNKJBKND_5_0_18_0.crx')
time.sleep(2)
extension_Protocol = "chrome-extension"
extension_ID = "bihmplhobchoageeokmgbdihknkjbknd"
indexPage = extension_Protocol + "://" + extension_ID + "/panel/index.html"